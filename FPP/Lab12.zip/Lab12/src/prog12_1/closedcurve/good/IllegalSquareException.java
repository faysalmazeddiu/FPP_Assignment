package prog12_1.closedcurve.good;

public class IllegalSquareException extends IllegalClosedCurveException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IllegalSquareException() {
		super();
	}

	public IllegalSquareException(String errMessage) {
		super(errMessage);
	}

}
