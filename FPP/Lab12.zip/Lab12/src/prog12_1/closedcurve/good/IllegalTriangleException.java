package prog12_1.closedcurve.good;

public class IllegalTriangleException extends IllegalClosedCurveException {

	public IllegalTriangleException() {
		super();
	}

	public IllegalTriangleException(String errMessage) {
		super(errMessage);
	}

}
