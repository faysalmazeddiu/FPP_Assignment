package prog12_1.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
