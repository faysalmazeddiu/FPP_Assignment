package prog4_4.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
