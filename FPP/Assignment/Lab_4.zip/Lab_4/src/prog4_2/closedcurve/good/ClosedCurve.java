package prog4_2.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
