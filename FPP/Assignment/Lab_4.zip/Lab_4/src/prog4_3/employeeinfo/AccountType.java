package prog4_3.employeeinfo;

public enum AccountType {
	CHECKING, SAVINGS, RETIREMENT
}
