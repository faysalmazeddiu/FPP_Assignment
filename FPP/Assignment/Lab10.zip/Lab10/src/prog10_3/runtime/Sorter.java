package prog10_3.runtime;

public abstract class Sorter {

	abstract public int[] sort(int[] arr);
}
