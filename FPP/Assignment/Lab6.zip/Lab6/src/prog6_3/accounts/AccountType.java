package prog6_3.accounts;

public enum AccountType {
	CHECKING, SAVINGS, RETIREMENT;
}
