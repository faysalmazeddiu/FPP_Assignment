package prog2_3;

public class Prog3 {
	public static void main(String[] args) {
		float firstFloatNumber=1.27f;
		float secondFloatNumber=3.881f;
		float thirdFloatNumber=9.6f;
		int sum=(int)(firstFloatNumber+secondFloatNumber+thirdFloatNumber);
		System.out.println(sum);
		sum=Math.round(firstFloatNumber+secondFloatNumber+thirdFloatNumber);
		System.out.println(sum);
		
		
	}
}
